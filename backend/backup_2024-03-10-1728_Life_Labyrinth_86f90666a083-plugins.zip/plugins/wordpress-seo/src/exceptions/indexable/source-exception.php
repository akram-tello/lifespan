<?php

namespace Yoast\WP\SEO\Exceptions\Indexable;

/**
 * Class Indexable_Source_Exception
 */
class Source_Exception extends Indexable_Exception {

}
